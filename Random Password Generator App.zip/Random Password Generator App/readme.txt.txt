A random password generator using HTML + CSS and JavaScript

