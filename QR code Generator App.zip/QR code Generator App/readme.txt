This is a QR code generator web based application created using HTML,CSS and JavaScript.

